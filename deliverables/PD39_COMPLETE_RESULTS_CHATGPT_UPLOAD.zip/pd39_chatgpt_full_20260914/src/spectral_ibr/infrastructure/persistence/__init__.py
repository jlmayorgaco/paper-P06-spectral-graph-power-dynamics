"""Persistence adapters."""

