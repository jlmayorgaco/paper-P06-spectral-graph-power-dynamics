"""Numerical solver adapters."""

