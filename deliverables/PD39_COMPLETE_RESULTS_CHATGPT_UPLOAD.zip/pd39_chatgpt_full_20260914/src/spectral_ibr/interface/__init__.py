"""CLI and composition root."""

