"""Pure domain services."""

