# Paquete para GPT Luna

1. Leer `GPT_Luna_IEEE39_Validacion_V1.md` como instrucción principal.
2. Extraer `inputs/pmu_nonlinear_em_reference.zip` para el núcleo de inferencia.
3. `EXPERIMENT_GENERATOR_EVALUATOR_CONFIG.json` es para generar/evaluar: contiene la verdad del evento. NO entregarlo íntegro al proceso del estimador.

El núcleo adjunto pasó pruebas algebraicas/sintéticas, pero no contiene una validación IEEE-39 ejecutada. Esta tarea es implementar y ejecutar esa validación, no afirmar que ya existe.

Método de la prueba: estimación de trayectoria condicionada al soporte de carga bus 7, sin conocer la amplitud ni el perfil temporal. Julia/PowerDynamics genera la verdad; Python consume sólo ocho PMUs; un evaluador separado compara contra los buses ocultos.
